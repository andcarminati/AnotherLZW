/* 
 * File:   compressor.h
 * Author: andreu
 *
 * Created on 3 de Maio de 2020, 15:18
 */

#ifndef COMPRESSOR_H
#define	COMPRESSOR_H

#define MAX_ENTRIES 4096
#define MAX_SEQ 50
#define LAST_UNUSED_ENTRY 256

typedef struct entry {
    unsigned char sequence[MAX_SEQ];
    short code;
    int size;
    int inUse;

} entry;

entry entries[MAX_ENTRIES];
int valueCount;


void reset();
int encode(int size, unsigned char* inData, unsigned char* outData);
int decode(int size, unsigned char* inData, unsigned char* outData);

#endif	/* COMPRESSOR_H */

