/* 
 * File:   main.c
 * Author: andreu
 *
 * Created on 3 de Maio de 2020, 12:52
 */

#include <stdio.h>
#include <stdlib.h>
#include "compressor.h"

const char block1[] = "Alice was beginning to get very tired of sitting by her sister on the bank, \n"
        "and of having nothing to do: once or twice she had peeped into the book her sister was reading, \n"
        "but it had no pictures or conversations in 'and what is the use of a book,' thought Alice \n"
        "'without pictures or conversations?\n";

const char block2[] = "\nSo she was considering in her own mind (as well as she could, for the hot day made \n"
        "her feel very sleepy and stupid), whether the pleasure of making a daisy-chain would \n"
        "be worth the trouble of getting up and picking the daisies, when suddenly a White Rabbit \n"
        "with pink eyes ran close by her.\n";

const char block3[] = "\nThere was nothing so VERY remarkable in that; nor did Alice think it so VERY \n"
        "much out of the way to hear the Rabbit say to itself, 'Oh dear! Oh dear! I shall be late!' \n"
        "(when she thought it over afterwards, it occurred to her that she ought to have wondered at \n"
        "this, but at the time it all seemed quite natural); but when the Rabbit actually TOOK A WATCH \n"
        "OUT OF ITS WAISTCOAT-POCKET, and looked at it. \n";


unsigned char comp_block1[500];
unsigned char comp_block2[500];
unsigned char comp_block3[500];

unsigned char uncomp_block1[500];
unsigned char uncomp_block2[500];
unsigned char uncomp_block3[500];

int main(int argc, char** argv) {

    int size_block1, size_block2, size_block3, i;
    int comp_size_block1, comp_size_block2, comp_size_block3;
    int uncomp_size_block1, uncomp_size_block2, uncomp_size_block3;

    size_block1 = sizeof (block1);
    size_block2 = sizeof (block2);
    size_block3 = sizeof (block3);

    printf("Original data...:\n");

    printf("Size of block 1: %d\n", size_block1);
    printf("Size of block 2: %d\n", size_block2);
    printf("Size of block 3: %d\n", size_block3);

    // reset compressor/decompressor
    reset();

    printf("\nCompressing...:\n");

    comp_size_block1 = encode(size_block1, (unsigned char*) block1, comp_block1);
    comp_size_block2 = encode(size_block2, (unsigned char*) block2, comp_block2);
    comp_size_block3 = encode(size_block3, (unsigned char*) block3, comp_block3);

    printf("Size of block 1 (compressed): %d (reduction of %f)\n",
            comp_size_block1, 1.0 - (comp_size_block1 / (double) size_block1));
    printf("Size of block 2 (compressed): %d (reduction of %f)\n", comp_size_block2,
            comp_size_block2, 1.0 - (comp_size_block2 / (double) size_block2));
    printf("Size of block 3 (compressed): %d (reduction of %f)\n",
            comp_size_block3, 1.0 - (comp_size_block3 / (double) size_block3));

    // reset compressor/decompressor again
    reset();

    printf("\nUncompressing...:\n");
    uncomp_size_block1 = decode(comp_size_block1, (unsigned char*) comp_block1, uncomp_block1);
    uncomp_size_block2 = decode(comp_size_block2, (unsigned char*) comp_block2, uncomp_block2);
    uncomp_size_block3 = decode(comp_size_block3, (unsigned char*) comp_block3, uncomp_block3);

    printf("Size of block 1 (decompressed): %d\n", uncomp_size_block1);
    printf("Size of block 2 (decompressed): %d\n", uncomp_size_block2);
    printf("Size of block 3 (decompressed): %d\n", uncomp_size_block3);

    printf("\nDumping result...:\n");

    for (i = 0; i < uncomp_size_block1; i++) {
        printf("%c", uncomp_block1[i]);
    }
    for (i = 0; i < uncomp_size_block2; i++) {
        printf("%c", uncomp_block2[i]);
    }
    for (i = 0; i < uncomp_size_block3; i++) {
        printf("%c", uncomp_block3[i]);
    }

    printf("\n");
    return 0;
}