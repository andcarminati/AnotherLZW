#include "compressor.h"
#include <stdio.h>
#include <string.h>

static int dict_get_code(unsigned char seq[], int size) {
    if (size == 1) {
        //  go direct to value
        return seq[0];
    }
    for (int i = LAST_UNUSED_ENTRY; i < valueCount; i++) {
        entry* elem = &entries[i];
        if (memcmp(elem->sequence, seq, size) == 0) {
            return elem->code;
        }
    }
    return -1;
}

static void fill_entry(entry* ent, unsigned char* seq, int size, int code) {
    if (size > MAX_SEQ) {
        printf("Overflow in dictionary entry\n");
        //exit(-1); // abort, igonred in this moment
    }
    memcpy(ent->sequence, seq, size);
    ent->code = code;
    ent->size = size;
    ent->inUse = 1;
}

static int insert_entry(unsigned char seq[], int size) {
    int code = valueCount;
    entry* entry_ = &entries[valueCount++];
    fill_entry(entry_, seq, size, code);
    return code;
}

static int exist_entry(short code) {
    entry* ent = &entries[code];
    return ent->inUse;
}

void reset() {
    int i;
    valueCount = 0;
    for (i = 0; i < LAST_UNUSED_ENTRY; i++) {
        insert_entry((unsigned char*) &i, 1);
    }
    for (i = LAST_UNUSED_ENTRY; i < MAX_ENTRIES; i++) {
        entries[i].inUse = 0;
    }
}

static int dict_contains(unsigned char seq[], int size) {
    int i;
    if (size == 1) {
        return 1;
    }
    for (i = LAST_UNUSED_ENTRY; i < valueCount; i++) {
        entry* elem = &entries[i];
        if (memcmp(elem->sequence, seq, size) == 0) {
            return 1;
        }
    }
    return 0;
}

static int dict_get_seq(short code, unsigned char** seq) {
    entry* ent = &entries[code];
    *seq = ent->sequence;
    return ent->size;
}

static int dict_is_full() {
    if (valueCount < MAX_ENTRIES) {
        return 0;
    }
    return 1;
}

static void compressed_write(short code, unsigned char* out_data, int* has_remaining,
        unsigned char* rest, int* write_pos) {
    
    if (*has_remaining) {
        unsigned char part4bits = code >> 8;
        unsigned char part8bits = code & 0x00FF;
        *rest = *rest | part4bits;
        out_data[(*write_pos)++] = *rest;
        out_data[(*write_pos)++] = part8bits;
        *has_remaining = 0;
    } else {
        unsigned char part8bits = code >> 4;
        unsigned char part4Bits = (code & 0x000F);
        *rest = part4Bits << 4;
        out_data[(*write_pos)++] = part8bits;
        *has_remaining = 1;
    }
}
/*
 * LZW Encode, transform byte sequences into 12-bit encoded data
 * with a dictionary with 4096 entries
 *  
*/

int encode(int size, unsigned char* in_data, unsigned char* out_data) {

    // compression vars
    unsigned char P[MAX_SEQ], C;
    int sizeP = 0;
    int out_pos = 0, i;
    // output vars
    unsigned char rest = 0;
    int has_remaining = 0, write_pos = 0;

    for (i = 0; i < size; i++) {
        C = in_data[i];
        P[sizeP] = C;
        if (dict_contains(P, sizeP + 1)) {
            sizeP++;
        } else {
            short code = dict_get_code(P, sizeP);
            compressed_write(code, out_data, &has_remaining, &rest, &write_pos);
            if (!dict_is_full()) {
                insert_entry(P, sizeP + 1);
            }
            P[0] = C;
            sizeP = 1;
        }
    }
    short code = dict_get_code(P, sizeP);
    compressed_write(code, out_data, &has_remaining, &rest, &write_pos);
    // write last remaining part
    if(has_remaining){
        compressed_write(0, out_data, &has_remaining, &rest, &write_pos);
    }
    return write_pos;
}

static unsigned short compressed_read(unsigned char* in_data, int* has_remaining,
        unsigned char* remaining, int* read_pos) {
    unsigned short value = 0;

    if (*has_remaining) {
        unsigned char part8bits = in_data[(*read_pos)++];
        value = (*remaining << 8) | part8bits;
        *has_remaining = 0;
    } else {
        unsigned char part8bits = in_data[(*read_pos)++];
        unsigned char part4bits = in_data[(*read_pos)++];
        *remaining = part4bits & 0x0F;
        value = (part8bits << 4) | (part4bits >> 4);
        *has_remaining = 1;
    }
    return value;
}

static inline void uncompressed_write(unsigned char* seq, int size, unsigned char* out_data, int* pos) {
    memcpy(out_data + (*pos), seq, size);
    *pos += size;
}

/*
 * LZW Decode, using standard 12 bit encoded data
 * with a dictionary with 4096 entries
 *  
*/
int decode(int size, unsigned char* in_data, unsigned char* out_data) {

    // decompression vars
    unsigned char P[MAX_SEQ], C;
    unsigned short Cw, Pw;
    int sizeP = 0, sizeCw;
    unsigned char* data;
    // input manag. vars
    int data_count = 0, total_data = size, has_remaining = 0;
    unsigned char rest = 0;
    // output control vars
    int out_pos = 0;

    Cw = compressed_read(in_data, &has_remaining, &rest, &data_count);
    sizeCw = dict_get_seq(Cw, &data);
    uncompressed_write(data, sizeCw, out_data, &out_pos);

    while (data_count < total_data) {
        Pw = Cw;
        Cw = compressed_read(in_data, &has_remaining, &rest, &data_count);

        if (exist_entry(Cw)) {
            sizeCw = dict_get_seq(Cw, &data);
            uncompressed_write(data, sizeCw, out_data, &out_pos);
            unsigned char* dataP;
            sizeP = dict_get_seq(Pw, &dataP);
            memcpy(P, dataP, sizeP);
            C = data[0];
            P[sizeP] = C;
            if (!dict_is_full()) {
                insert_entry(P, sizeP + 1);
            }
        } else {
            unsigned char* dataP;
            sizeP = dict_get_seq(Pw, &dataP);
            memcpy(P, dataP, sizeP);
            C = dataP[0];
            P[sizeP] = C;
            uncompressed_write(P, sizeP + 1, out_data, &out_pos);
            if (!dict_is_full()) {
                insert_entry(P, sizeP + 1);
            }
        }
    }
    return out_pos;
}
